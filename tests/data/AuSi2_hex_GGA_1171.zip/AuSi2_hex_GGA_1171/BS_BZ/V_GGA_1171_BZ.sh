#!/bin/sh
#SBATCH -N 2
#SBATCH --ntasks-per-node 24
#SBATCH --time=350:00:00
#SBATCH -p gpu
#
ulimit -s unlimited
cd /storage/home/krawiec/VASP_DATA/AuSi2_hex_GGA_1171/BS_BZ
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/storage/opt/intel/mkl/lib/intel64
export OMP_NUM_THREADS=1
for i in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 ; do
cp KPOINTS.$i KPOINTS
mpirun -env I_MPI_DEVICE sock -n 48 /storage/home/krawiec/vasp.6.4.2/bin/vasp_std > dane.out
mv PROCAR PROCAR.$i
mv OUTCAR OUTCAR.$i
done
