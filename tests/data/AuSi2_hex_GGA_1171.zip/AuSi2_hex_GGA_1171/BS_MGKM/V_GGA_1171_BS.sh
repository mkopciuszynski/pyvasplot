#!/bin/sh
#SBATCH -N 2
#SBATCH --ntasks-per-node 24
#SBATCH -p gpu
#
ulimit -s unlimited
cd /storage/home/krawiec/VASP_DATA/AuSi2_hex_GGA_1171/BS_MGKM
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/storage/opt/intel/mkl/lib/intel64
export OMP_NUM_THREADS=1
mpirun -env I_MPI_DEVICE sock -n 48 /storage/home/krawiec/vasp.6.4.2/bin/vasp_std > dane.out

